package com.fox.academy_lesson1.ex6_persistance;

public class NewsAsyncDao {
}
