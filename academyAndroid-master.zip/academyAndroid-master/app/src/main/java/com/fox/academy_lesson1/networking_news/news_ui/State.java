package com.fox.academy_lesson1.networking_news.news_ui;



public enum State {
    HasNoData,
    Loading,
    NetworkingError,
    ServerError,
    HasData
}
